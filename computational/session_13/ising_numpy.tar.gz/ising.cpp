//#include <stdio.h>
#include <iostream>
#include <cmath>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
using namespace std;

#include "ising.h"


const int dimension = 2;


//**************************************************************************


void mc_init (int *array, int arrlength)
{
  int i;

  // generate a random configuration to start and find its energy
  for (i = 0; i < arrlength; i++)
  {
    if (array[i] == 1) {
    array[i] = 1;
    } else if (array[i] == 0) {
      array[i] = -1;  
    }

  }
  //  energy0 = calculate_energy ();

}

//************************* calculate_energy ******************************
//
//  Given the array of integers configuration[0...num_sites-1], which 
//   specifies the spin at each lattice point, find the energy of that 
//   configuration [eq.(13.6) in Session 13 notes].
//  Note that a freeboundary condition is specified here.
//
//*************************************************************************
double 
calculate_energy (int *array, int arrlength)
{
  int nearest = 0;
  double energy = 0.;
  double J_ising = 1.;
  int i,j;

  if (dimension == 1) 
  { 
    for (i = 0; i < arrlength - 1; i++)  // step through all but one site
    {
      nearest = i + 1;   // nearest neighbor on a line
      energy += - J_ising * double(array[i] * array[nearest]);
    }
    
    // now for the last site using periodic boundary conditions
    nearest = arrlength - 1;
    energy += - J_ising * double(array[nearest] * array[0]);
  }
  else if (dimension == 2)
  {  
    int linear_sites = int(sqrt(arrlength));
  // go through the 2d lattice with free boundary conditions
    for (i = 0; i < linear_sites - 1; i++)
    {
      for (j = 0; j < linear_sites - 1; j++)
      {
        int id = i + j * linear_sites;

        // x direction
        nearest = id + 1;
        energy += - J_ising * double(array[id]*array[nearest]);

        // y direction;
        nearest = id + linear_sites;
        energy += - J_ising * double(array[id]*array[nearest]);
      }
    }
  }

  return (energy);
} 


double mc_step (int *array, int arrlength, double *randval, int arrlength2, unsigned long int random_seed, double energy0)
{
  double kT = 2.;          // temperature (in energy units)

  //  cout << "Testing" << endl;


  // Find the energy distribution from a Markov chain of configurations
  double energy;

 //  Set up the GSL random number generators (rng's)
  gsl_rng *rng_ptr = gsl_rng_alloc (gsl_rng_taus);   // allocate an rng 
  gsl_rng_set (rng_ptr, random_seed);                // seed the rng 

  int i;
  //  printf("arrlength2 = %d \n",arrlength2);

    for (i = 0; i < arrlength; i++)  // Entire loop is only one mcs  
    {
      // pick a random lattice site
      double random = gsl_ran_flat (rng_ptr, 0., 1.);
      int id = int(random * arrlength);
      //      cout << "id = " << id << endl;
      //      int id = int(randsite[i] * num_sites);  // from 0 to num_sites

      // flip that spin (i.e., if +/- 1, change to -/+ 1)
      energy = calculate_energy(array,arrlength);  // new energy
      //      cout << "energy = " << energy << endl;

      array[id] *= -1;  

      energy = calculate_energy(array,arrlength);  // new energy
      cout << "energy = " << energy << endl;
      double delta_energy = energy - energy0;
      //      cout << "delta_energy = " << delta_energy << endl;

      // decide whether to accept or reject the new configuration
      //      random = gsl_ran_flat (rng_ptr, 0., 1.);
      //      cout << "randval[i] = " << randval[i] << endl;
      if ( (delta_energy > 0.) && (randval[i] > exp(-delta_energy/kT)) )
      {
        // reject the new configuration: flip the spin back
        array[id] *= -1; 
      }
      else
      {
        energy0 = energy;  // accept the new configuration
      }
    }

    return energy0;
}
