void mc_init (int *array, int arrlength);
double calculate_energy (int *array, int arrlength);
double mc_step (int *array, int arrlength, double *randval, int arrlength2, unsigned long int random_seed, double energy0);
