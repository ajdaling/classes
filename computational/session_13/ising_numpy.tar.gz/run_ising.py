#!/usr/bin/env python

#Load in standard stuff
import numpy
from matplotlib.pylab import *

#Load in python module for Ising model
import ising

#Turn "interactive" on
ion()

#XDIM=ising_routines.get_linear_sites()

XDIM=10

#Initialize plot with a bunch of random numbers
matshow(around(rand(XDIM,XDIM)),fignum=1,cmap=cm.gray)
gca().set_xticklabels('')
gca().set_yticklabels('')
title('2-D Ising Model')

#Initialize the domain
A = numpy.around(rand(XDIM*XDIM)).astype('Int32')
ising.mc_init(A)

Energy0=ising.calculate_energy(A)
print Energy0

MAX_SEED_INT=100000

for k in arange(1,100):
    Energy0=ising.mc_step(A,rand(XDIM*XDIM),randint(0,MAX_SEED_INT),Energy0)
#    print Energy0    
    matshow(reshape(A,[XDIM,XDIM]),fignum=1,cmap=cm.gray)
#    matshow(around(rand(XDIM,XDIM)),fignum=1,cmap=cm.gray)
    draw()
