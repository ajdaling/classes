swig  -c++ -python ising.i
sed -i -e 's/char \*doc/const char *doc/g' ising_wrap.cxx
sed -i -e 's/char \*c = methods/const char *c = methods/g' ising_wrap.cxx
sed -i -e 's/char \*name = c/const char *name = c/g' ising_wrap.cxx
g++ -c ising.cpp ising_wrap.cxx -I/usr/local/include/python2.6 -I/usr/local/lib/python2.6/site-packages/numpy/core/include
g++ -shared ising.o ising_wrap.o -lm -lgsl -lgslcblas -L/usr/lib -lstdc++ -o _ising.so
