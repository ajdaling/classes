//Alec Daling -- 1/22/17
helloworld.cpp Closed Lab 1 Ex 2

include <iostream>
using namespace std;
int main({
	cout << "Hello World" << endl;
	return 0;
}
